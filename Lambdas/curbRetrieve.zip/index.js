var AWS = require('aws-sdk');
var DOC = require('dynamodb-doc');
var dynamo = new DOC.DynamoDB();

exports.handler = function(event, context) {
    try
    {
        var msg_callback = function(err, data)
        {
            if (err)
            {//Handles all errors need to break it down for specific erros to display appropriate error messages
                    console.log('error on getUserInfo: ', err);
                    context.done('Unable to retrieve user information.', null);
            }
            else
            {
                console.log(data.Item);// Remember data is pushed using the Item key as a param of the DynamoDB putItem
                if(data.Item)
                {
                context.done(null,data.Item);
                }
                else
                {
                    console.log("Did not find anything.");
                    context.done(null, {});//Prints empty object if nothing is contained in Item (<- ironic ?)
                }
            }
        };
        
        console.log("sender - " + event.senderid + " date - " + event.date);
        
      dynamo.getItem({TableName:"ProjectAlpha_Msg", Key:{MessageID:event.MessageID}}, msg_callback);

    }
    catch(error)
    {
        context.fail("Caught: " + error);
    }
};
