var AWS = require('aws-sdk');
var DOC = require('dynamodb-doc');
var dynamo = new DOC.DynamoDB();
var PubNub = require('pubnub');
var https = require('https');
var uuid = require ('uuid');

exports.handler = function(event, context) {

    // TODO implement
	console.log(event);
	var json={};


    var db_callback = function(err, data) {
    if (err) {
      console.log(err);
      context.fail('unable to update at this time');
    }
    else {

      var pubnub = new PubNub({
                        subscribeKey: "sub-c-cc11b4d4-8fa8-11e6-a8c4-0619f8945a4f",
                        publishKey: "pub-c-e2f048dc-74a5-4283-a99d-c54f98734cb0’",
                        secretKey: "sec-c-MjIyOTJmZmMtNmNkZi00YjliLWFkN2MtMDE1YzU4NmE3NjQ1",
                        logVerbosity: true,
                        ssl: true,
                        presenceTimeout: 130
                    });


                    function publishSampleMessage(pubnub, notify) {

                        pubnub.publish(
                            {
                                    message: notify ,
                                    channel: notify.channelID,// <- ChannelID
                            },
                            function (status, response) {
                                // handle status, response
                                //console.log(response);
                                var msgObj = {};
                                msgObj.time = event.Date.toString();
                                msgObj.MessageID = event.MessageID;
                                context.done(null, msgObj); //Passing to the client the msg UTC Time
                            }
                        );


                    }

                    var notify = {

                      "MessageID":  event.MessageID,
                      "SenderID":  event.SenderID,
                      "RecipientID": event.RecipientID,
                      "Date": event.Date.toString()
                    };

                    publishSampleMessage(pubnub, notify);

    }
  };


    var sendMessage = function () {
      str="";
			  json = {

					"recipient": {"id": event.RecipientID},
					"message": {"text": event.Msg}

				  };

          event.MessageID = uuid.v4().toString();

          var date = new Date();

          event.Date = date.getTime().toString();

          console.log(event);

          console.log("event" + event.MessageID + "  str " + str.message_id);
          dynamo.putItem({TableName:"ProjectAlpha_Msg", Item: event}, db_callback);
    };

 var getItemCallback = function(err, data) {
      if (err)
      {
        console.log(err);
        context.fail('unable to fetch user perms from db');
      }
      else
	  {
		  //console.log("User found");
		  //console.log(data.Item);
		  sendMessage();
		  }
	  }
	 

    dynamo.getItem({TableName:"Users", Key:{user_email:event.user_email}}, getItemCallback);

  //context.done(null, event);
};
